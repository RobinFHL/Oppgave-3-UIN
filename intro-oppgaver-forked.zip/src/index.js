// Oppgave 1
const removeButton = document.getElementById("remove-btn");
const removeText = document.getElementById("remove");

removeButton.addEventListener("click", () => {
  removeText.style.display = "none";
});

// Oppgave 2
const changeButton = document.getElementById("change-btn");
const changeText = document.getElementById("change");

changeButton.addEventListener("click", () => {
  changeText.innerText = "Jeg har nå endret denne teksten";
});

// Oppgave 3
const input = document.getElementById("input");
const inputText = document.getElementById("input-text");

input.addEventListener("keypress", function (e) {
  if (13 == e.keyCode) {
    inputText.innerText = input.value;
  }
});

// Oppgave 4
const listButton = document.getElementById("write-list");
const myList = ["item one", "item two", "item three"];

listButton.addEventListener("click", () => {
  document.getElementById("ul").innerHTML =
    "<li>" +
    myList[0] +
    "</li><li>" +
    myList[1] +
    "</li><li>" +
    myList[2] +
    "</li>";
});

// Oppgave 5
const buttonCreate = document.getElementById("create");
const Selector = document.getElementById("select");
const inputBox = document.getElementById("text");
const placeholderText = document.getElementById("placeholder");

buttonCreate.addEventListener("click", () => {
  //placeholderText.innerText = Selector.value;
  placeholderText.innerText =
    "<" + Selector.value + ">" + inputBox.value + "</" + Selector.value + ">";
});
// Oppgave 6
const removeList = document.getElementById("remove-li");
const li = document.getElementById("list");

removeList.addEventListener("click", () => {
  li.removeChild(li.childNodes[0]);
});

// Oppgave 7
const order = document.getElementById("order");
const name = document.getElementById("name");

name.addEventListener("keydown", function (e) {
  if (name.value > "") {
    order.style.borderColor = "red";
    order.disabled = true;
  }
});
// Oppgave 8
const childrenList = document.getElementsByClassName("children")[0];
const buttonColor = document.getElementById("color");

buttonColor.addEventListener("click", () => {
  if ((childrenList.childNodes == [0], [2], [4])) {
    childrenList.style.borderColor = "green";
  } 
  else if ((childrenList.childNodes == [1], [3])) {
    childrenList.style.borderColor = "pink";
  }
});
